const fs=require('fs');
const express=require("express");
const bodyParser=require("body-parser"); 

fs.copyFileSync("file1.txt","file2.txt");
const App=express();
App.use(bodyParser.urlencoded({extended:true}));

App.get("/",(req,res)=>{
    res.sendFile(__dirname+"/index.html");
});


App.get("/about",(req,res)=>{
    res.send("Welcome to Muneeb's World. Hope you are doing good.");
});

App.post("/",(req,res)=>{
    
    var n1=Number(req.body.n1);
    var n2=Number(req.body.n2);
    var result=n1+n2;
    res.send("The answer is "+result);


});

App.listen(3000,()=>{//arrow callback function
    console.log("The server has started running on port 3000");
});












//install nodemon package from npm for continuous server tracking for any changes. You wont have to restart the server again and again nodemon index.js